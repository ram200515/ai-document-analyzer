"""
AI Document Analyzer — Python Flask Backend
Connects SAP UI5 frontend to LLaMA API via Groq
Author: Adithyaram Gude
"""

import os
import time
import json
from flask import Flask, request, jsonify
from flask_cors import CORS
from groq import Groq
import PyPDF2
import io

# ─── App Setup ───────────────────────────────────────────────────────────────
app = Flask(__name__)
CORS(app)   # Allow SAP UI5 frontend to call this API

# ─── Groq / LLaMA Config ─────────────────────────────────────────────────────
# Set your Groq API key in environment: export GROQ_API_KEY="your_key_here"
GROQ_API_KEY = os.environ.get("GROQ_API_KEY", "your_groq_api_key_here")
client       = Groq(api_key=GROQ_API_KEY)
LLAMA_MODEL  = "llama3-8b-8192"   # Fast, free on Groq

# ─── Analysis Prompts ─────────────────────────────────────────────────────────
PROMPTS = {
    "summarize": """
You are an enterprise document analyst. Summarize the following document concisely.
Return your response in this EXACT JSON format:
{{
  "title": "Document Summary",
  "result": "<p><strong>Overview:</strong> [2-3 sentence overview]</p><p><strong>Details:</strong> [key details]</p><p><strong>Conclusion:</strong> [conclusion]</p>",
  "insights": [
    {{"id": 1, "category": "Main Theme",  "insight": "...", "state": "Success"}},
    {{"id": 2, "category": "Key Finding", "insight": "...", "state": "Warning"}},
    {{"id": 3, "category": "Action",      "insight": "...", "state": "Information"}}
  ],
  "confidence": 95
}}
Document: {text}
""",

    "keypoints": """
You are a business analyst. Extract the key points from this document.
Return EXACT JSON:
{{
  "title": "Key Points Extracted",
  "result": "<ul><li><strong>Point 1:</strong> ...</li><li><strong>Point 2:</strong> ...</li><li><strong>Point 3:</strong> ...</li></ul>",
  "insights": [
    {{"id": 1, "category": "Critical",   "insight": "...", "state": "Error"}},
    {{"id": 2, "category": "Important",  "insight": "...", "state": "Warning"}},
    {{"id": 3, "category": "Supporting", "insight": "...", "state": "Success"}}
  ],
  "confidence": 92
}}
Document: {text}
""",

    "sentiment": """
You are a sentiment analysis expert. Analyze the sentiment of this document.
Return EXACT JSON:
{{
  "title": "Sentiment Analysis",
  "result": "<p><strong>Overall Sentiment:</strong> [Positive/Negative/Neutral]</p><p><strong>Tone:</strong> [describe tone]</p><p><strong>Emotional Indicators:</strong> [list key phrases that indicate sentiment]</p>",
  "insights": [
    {{"id": 1, "category": "Overall",  "insight": "...", "state": "Success"}},
    {{"id": 2, "category": "Positive", "insight": "...", "state": "Success"}},
    {{"id": 3, "category": "Negative", "insight": "...", "state": "Error"}},
    {{"id": 4, "category": "Neutral",  "insight": "...", "state": "Information"}}
  ],
  "confidence": 88
}}
Document: {text}
""",

    "action_items": """
You are a project manager. Extract all action items and tasks from this document.
Return EXACT JSON:
{{
  "title": "Action Items",
  "result": "<ol><li><strong>Action 1:</strong> [who] must [what] by [when]</li><li><strong>Action 2:</strong> ...</li></ol>",
  "insights": [
    {{"id": 1, "category": "High Priority",   "insight": "...", "state": "Error"}},
    {{"id": 2, "category": "Medium Priority", "insight": "...", "state": "Warning"}},
    {{"id": 3, "category": "Low Priority",    "insight": "...", "state": "Success"}}
  ],
  "confidence": 90
}}
Document: {text}
""",

    "risks": """
You are a risk analyst. Identify all risks, issues, and concerns in this document.
Return EXACT JSON:
{{
  "title": "Risk Analysis",
  "result": "<p><strong>Risk Level:</strong> [High/Medium/Low]</p><ul><li><strong>Risk 1:</strong> [description and impact]</li><li><strong>Risk 2:</strong> ...</li></ul><p><strong>Mitigation:</strong> [suggestions]</p>",
  "insights": [
    {{"id": 1, "category": "High Risk",    "insight": "...", "state": "Error"}},
    {{"id": 2, "category": "Medium Risk",  "insight": "...", "state": "Warning"}},
    {{"id": 3, "category": "Opportunity",  "insight": "...", "state": "Success"}}
  ],
  "confidence": 87
}}
Document: {text}
"""
}

# ─── Helper: Extract text from PDF ───────────────────────────────────────────
def extract_pdf_text(file_bytes):
    try:
        reader = PyPDF2.PdfReader(io.BytesIO(file_bytes))
        text   = ""
        for page in reader.pages:
            text += page.extract_text() + "\n"
        return text.strip()
    except Exception as e:
        raise ValueError(f"Failed to extract PDF text: {str(e)}")

# ─── Helper: Count words ──────────────────────────────────────────────────────
def count_words(text):
    return len(text.split())

# ─── Helper: Truncate text for API limits ────────────────────────────────────
def truncate_text(text, max_words=1500):
    words = text.split()
    if len(words) > max_words:
        return " ".join(words[:max_words]) + "... [truncated]"
    return text

# ─── Routes ───────────────────────────────────────────────────────────────────

@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "model": LLAMA_MODEL})


@app.route("/analyze", methods=["POST"])
def analyze():
    try:
        # ── 1. Extract text from request ──────────────────────────────────
        if request.content_type and "multipart" in request.content_type:
            # PDF upload
            if "file" not in request.files:
                return jsonify({"error": "No file uploaded"}), 400

            file      = request.files["file"]
            raw_bytes = file.read()
            text      = extract_pdf_text(raw_bytes)
            file_name = file.filename
            analysis_type = request.form.get("analysis_type", "summarize")

        else:
            # JSON text upload
            data          = request.get_json()
            text          = data.get("text", "").strip()
            analysis_type = data.get("analysis_type", "summarize")
            file_name     = data.get("file_name", "document.txt")

        if not text:
            return jsonify({"error": "No text content found in document"}), 400

        # ── 2. Validate analysis type ──────────────────────────────────────
        if analysis_type not in PROMPTS:
            return jsonify({"error": f"Invalid analysis type: {analysis_type}"}), 400

        # ── 3. Prepare prompt ──────────────────────────────────────────────
        word_count    = count_words(text)
        truncated     = truncate_text(text)
        prompt        = PROMPTS[analysis_type].format(text=truncated)

        # ── 4. Call LLaMA via Groq API ────────────────────────────────────
        start_time = time.time()

        completion = client.chat.completions.create(
            model    = LLAMA_MODEL,
            messages = [
                {
                    "role":    "system",
                    "content": "You are an enterprise document analysis AI. Always respond with valid JSON only. No markdown, no explanation outside the JSON."
                },
                {
                    "role":    "user",
                    "content": prompt
                }
            ],
            temperature = 0.3,
            max_tokens  = 1500
        )

        elapsed = round(time.time() - start_time, 1)

        # ── 5. Parse LLaMA response ────────────────────────────────────────
        raw_response = completion.choices[0].message.content.strip()

        # Clean up any accidental markdown fences
        if raw_response.startswith("```"):
            raw_response = raw_response.split("```")[1]
            if raw_response.startswith("json"):
                raw_response = raw_response[4:]

        result_data = json.loads(raw_response)

        # ── 6. Add metadata ────────────────────────────────────────────────
        result_data["word_count"]      = word_count
        result_data["processing_time"] = elapsed
        result_data["file_name"]       = file_name

        return jsonify(result_data), 200

    except json.JSONDecodeError:
        return jsonify({
            "error":      "AI returned an unexpected format. Please try again.",
            "raw":        raw_response[:200] if 'raw_response' in locals() else ""
        }), 500

    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ─── Run ─────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("🚀 AI Document Analyzer Backend running on http://localhost:5000")
    print(f"   Model: {LLAMA_MODEL}")
    print("   Set GROQ_API_KEY env variable before starting!")
    app.run(debug=True, port=5000)
