-- ============================================================
-- AI Document Analyzer — MySQL Database Schema
-- Author: Adithyaram Gude
-- ============================================================

CREATE DATABASE IF NOT EXISTS ai_doc_analyzer;
USE ai_doc_analyzer;

-- ── Table 1: Documents ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS documents (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    file_name       VARCHAR(255)    NOT NULL,
    file_type       VARCHAR(10)     NOT NULL,          -- txt / pdf
    word_count      INT             DEFAULT 0,
    uploaded_at     DATETIME        DEFAULT CURRENT_TIMESTAMP
);

-- ── Table 2: Analyses ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS analyses (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    document_id     INT             NOT NULL,
    analysis_type   VARCHAR(50)     NOT NULL,          -- summarize / keypoints etc
    result_text     TEXT,
    confidence      INT             DEFAULT 0,
    processing_time FLOAT           DEFAULT 0.0,
    created_at      DATETIME        DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (document_id) REFERENCES documents(id) ON DELETE CASCADE
);

-- ── Table 3: Insights ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS insights (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    analysis_id     INT             NOT NULL,
    category        VARCHAR(100),
    insight_text    TEXT,
    state           VARCHAR(20),                       -- Success / Warning / Error
    FOREIGN KEY (analysis_id) REFERENCES analyses(id) ON DELETE CASCADE
);

-- ── Sample Query: Recent Analyses ─────────────────────────────
-- SELECT d.file_name, a.analysis_type, a.confidence, a.created_at
-- FROM analyses a
-- JOIN documents d ON a.document_id = d.id
-- ORDER BY a.created_at DESC LIMIT 10;
