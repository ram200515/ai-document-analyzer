-- AI Document Analyzer Database Schema
-- Developer: Adithyaram Gude
-- Run this file in MySQL Workbench or terminal

CREATE DATABASE IF NOT EXISTS ai_doc_analyzer_db;
USE ai_doc_analyzer_db;

CREATE TABLE IF NOT EXISTS users (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    name       VARCHAR(100),
    email      VARCHAR(100),
    created_at DATETIME DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS documents (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT,
    file_name   VARCHAR(255),
    file_type   VARCHAR(50),
    word_count  INT,
    upload_date DATETIME DEFAULT NOW(),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS analysis_results (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    document_id     INT,
    analysis_type   VARCHAR(50),
    confidence      INT,
    processing_time DECIMAL(5,2),
    created_at      DATETIME DEFAULT NOW(),
    FOREIGN KEY (document_id) REFERENCES documents(id)
);

CREATE TABLE IF NOT EXISTS insights (
    id        INT AUTO_INCREMENT PRIMARY KEY,
    result_id INT,
    category  VARCHAR(50),
    insight   TEXT,
    state     VARCHAR(20),
    FOREIGN KEY (result_id) REFERENCES analysis_results(id)
);

-- Sample seed data
INSERT INTO users (name, email) VALUES ('Adithyaram Gude', 'adithyaramgude@gmail.com');

INSERT INTO documents (user_id, file_name, file_type, word_count, upload_date) VALUES
(1, 'business_report.pdf',   'PDF', 1250, '2026-06-10 09:32:11'),
(1, 'meeting_notes.txt',     'TXT',  430, '2026-06-11 11:15:44'),
(2, 'project_proposal.pdf',  'PDF', 2100, '2026-06-12 14:22:07'),
(1, 'risk_assessment.txt',   'TXT',  890, '2026-06-13 10:05:33'),
(2, 'quarterly_review.pdf',  'PDF', 1670, '2026-06-14 16:48:19');

INSERT INTO analysis_results (document_id, analysis_type, confidence, processing_time, created_at) VALUES
(1, 'summarize',    95, 2.30, '2026-06-10 09:35:22'),
(2, 'keypoints',    92, 1.80, '2026-06-11 11:18:05'),
(3, 'risks',        87, 3.10, '2026-06-12 14:26:41'),
(4, 'action_items', 90, 2.70, '2026-06-13 10:09:17'),
(5, 'sentiment',    88, 1.50, '2026-06-14 16:51:33');

INSERT INTO insights (result_id, category, insight, state) VALUES
(1, 'Main Theme',   'Document focuses on Q2 revenue growth strategies',    'Success'),
(1, 'Key Finding',  '23% increase in customer acquisition noted',           'Warning'),
(1, 'Action',       'Budget review meeting required before July 2026',      'Information'),
(2, 'Critical',     'Sprint deadline conflicts with QA cycle',              'Error'),
(3, 'High Risk',    'Supply chain delays may impact Q3 delivery targets',   'Error');
