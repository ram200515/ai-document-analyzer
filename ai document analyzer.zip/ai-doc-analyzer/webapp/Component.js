sap.ui.define([
    "sap/ui/core/UIComponent",
    "sap/ui/model/json/JSONModel"
], function (UIComponent, JSONModel) {
    "use strict";

    return UIComponent.extend("com.adithya.aidocanalyzer.Component", {
        metadata: {
            manifest: "json"
        },

        init: function () {
            // Call parent init FIRST (mandatory in UI5)
            UIComponent.prototype.init.apply(this, arguments);

            // Initialize router
            this.getRouter().initialize();

            // Global app model
            var oAppModel = new JSONModel({
                recentAnalyses: [],
                result:         {},
                currentFileName: ""
            });
            this.setModel(oAppModel, "appModel");
        }
    });
});
