sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageToast",
    "sap/m/MessageBox"
], function (Controller, MessageToast, MessageBox) {
    "use strict";

    return Controller.extend("com.adithya.aidocanalyzer.controller.Result", {

        onInit: function () {
            // Route match handler
            var oRouter = this.getOwnerComponent().getRouter();
            oRouter.getRoute("result").attachPatternMatched(this._onRouteMatched, this);
        },

        _onRouteMatched: function () {
            // Scroll to top when navigating here
            var oPage = this.byId("resultPage");
            if (oPage) { oPage.scrollTo(0); }
        },

        // ── Navigation ─────────────────────────────────────────────────────
        onNavBack: function () {
            this.getOwnerComponent().getRouter().navTo("home");
        },

        onNewAnalysis: function () {
            this.getOwnerComponent().getRouter().navTo("home");
        },

        // ── Export as JSON ─────────────────────────────────────────────────
        onExport: function () {
            var oModel  = this.getOwnerComponent().getModel("appModel");
            var oResult = oModel.getProperty("/result");

            if (!oResult) {
                MessageToast.show("No result to export.");
                return;
            }

            var sJSON    = JSON.stringify(oResult, null, 2);
            var oBlob    = new Blob([sJSON], { type: "application/json" });
            var sUrl     = URL.createObjectURL(oBlob);
            var oAnchor  = document.createElement("a");

            oAnchor.href     = sUrl;
            oAnchor.download = "analysis_result.json";
            oAnchor.click();
            URL.revokeObjectURL(sUrl);

            MessageToast.show("Exported as JSON!");
        },

        // ── Copy to Clipboard ──────────────────────────────────────────────
        onCopy: function () {
            var oModel  = this.getOwnerComponent().getModel("appModel");
            var oResult = oModel.getProperty("/result");

            if (!oResult) {
                MessageToast.show("Nothing to copy.");
                return;
            }

            // Strip HTML tags from mainOutput for clean clipboard text
            var sClean = oResult.mainOutput.replace(/<[^>]+>/g, "");

            navigator.clipboard.writeText(sClean).then(function () {
                MessageToast.show("Copied to clipboard!");
            }).catch(function () {
                MessageBox.error("Clipboard access denied. Please copy manually.");
            });
        }
    });
});
