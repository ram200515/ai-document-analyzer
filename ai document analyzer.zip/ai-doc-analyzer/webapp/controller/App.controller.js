sap.ui.define([
    "sap/ui/core/mvc/Controller"
], function (Controller) {
    "use strict";
    return Controller.extend("com.adithya.aidocanalyzer.controller.App", {
        onInit: function () {
            // App-level init
        }
    });
});
