sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "sap/m/MessageBox"
], function (Controller, JSONModel, MessageToast, MessageBox) {
    "use strict";

    // ─── CONFIG ──────────────────────────────────────────────────────────────
    const BACKEND_URL = "http://localhost:5000";   // Python Flask backend
    // ─────────────────────────────────────────────────────────────────────────

    return Controller.extend("com.adithya.aidocanalyzer.controller.Home", {

        // ── Lifecycle ──────────────────────────────────────────────────────
        onInit: function () {
            // Initialize app-level JSON Model
            var oModel = new JSONModel({
                recentAnalyses: [],
                currentFile: null,
                currentFileName: ""
            });
            this.getOwnerComponent().setModel(oModel, "appModel");
            this._fileContent = null;
        },

        // ── File Upload Handler ────────────────────────────────────────────
        onFileChange: function (oEvent) {
            var oFile = oEvent.getParameter("files")[0];

            if (!oFile) {
                return;
            }

            // Validate file size (max 5MB)
            if (oFile.size > 5 * 1024 * 1024) {
                MessageBox.error("File size exceeds 5MB. Please upload a smaller file.");
                return;
            }

            var sFileName = oFile.name;
            var oReader  = new FileReader();

            oReader.onload = function (e) {
                this._fileContent = e.target.result;  // raw text content

                // Update UI
                var oFileText = this.byId("fileNameText");
                oFileText.setText("✅ Selected: " + sFileName);
                oFileText.setVisible(true);

                // Enable analyze button
                this.byId("analyzeBtn").setEnabled(true);

                // Store filename in model
                this.getOwnerComponent()
                    .getModel("appModel")
                    .setProperty("/currentFileName", sFileName);

                MessageToast.show("File loaded successfully!");
            }.bind(this);

            oReader.onerror = function () {
                MessageBox.error("Failed to read file. Please try again.");
            };

            // Read as text (works for .txt; for PDF use backend extraction)
            if (oFile.type === "application/pdf") {
                // For PDF — send raw file to backend as FormData
                this._rawFile = oFile;
                this._fileContent = "__PDF__";  // sentinel value

                var oFileText = this.byId("fileNameText");
                oFileText.setText("✅ Selected PDF: " + sFileName);
                oFileText.setVisible(true);
                this.byId("analyzeBtn").setEnabled(true);

                this.getOwnerComponent()
                    .getModel("appModel")
                    .setProperty("/currentFileName", sFileName);
            } else {
                oReader.readAsText(oFile);
            }
        },

        onTypeMismatch: function () {
            MessageBox.warning("Only .txt and .pdf files are supported.");
        },

        // ── Analyze Button ─────────────────────────────────────────────────
        onAnalyzePress: function () {
            if (!this._fileContent) {
                MessageToast.show("Please select a file first.");
                return;
            }

            var sAnalysisType = this.byId("analysisType").getSelectedKey();
            this._startAnalysis(sAnalysisType);
        },

        // ── Core Analysis Logic ────────────────────────────────────────────
        _startAnalysis: function (sAnalysisType) {
            var that = this;

            // Show busy state
            this.byId("busyIndicator").setVisible(true);
            this.byId("analyzeBtn").setEnabled(false);
            this.byId("statusText").setText("🤖 Sending to LLaMA API...");

            var oModel    = this.getOwnerComponent().getModel("appModel");
            var sFileName = oModel.getProperty("/currentFileName");
            var tStart    = Date.now();

            // Build payload
            var oPayload;
            var fetchOptions;

            if (this._fileContent === "__PDF__") {
                // PDF: send as multipart FormData
                var formData = new FormData();
                formData.append("file", this._rawFile);
                formData.append("analysis_type", sAnalysisType);

                fetchOptions = { method: "POST", body: formData };
                oPayload     = null;
            } else {
                // Text: send as JSON
                oPayload = {
                    text:          this._fileContent,
                    analysis_type: sAnalysisType,
                    file_name:     sFileName
                };
                fetchOptions = {
                    method:  "POST",
                    headers: { "Content-Type": "application/json" },
                    body:    JSON.stringify(oPayload)
                };
            }

            fetch(BACKEND_URL + "/analyze", fetchOptions)
                .then(function (response) {
                    if (!response.ok) {
                        return response.json().then(function (err) {
                            throw new Error(err.error || "Server error");
                        });
                    }
                    return response.json();
                })
                .then(function (data) {
                    var processingTime = ((Date.now() - tStart) / 1000).toFixed(1);

                    // Build result object for Result view
                    var oResult = {
                        fileName:      sFileName,
                        analysisType:  that._formatAnalysisLabel(sAnalysisType),
                        analysisTitle: data.title || "Analysis Complete",
                        mainOutput:    data.result || "",
                        insights:      data.insights || [],
                        wordCount:     data.word_count || 0,
                        confidence:    data.confidence || 95,
                        processingTime: processingTime
                    };

                    // Save to model
                    oModel.setProperty("/result", oResult);

                    // Add to recent list
                    var aRecent = oModel.getProperty("/recentAnalyses") || [];
                    aRecent.unshift({
                        fileName:     sFileName,
                        analysisType: that._formatAnalysisLabel(sAnalysisType)
                    });
                    if (aRecent.length > 5) { aRecent = aRecent.slice(0, 5); }
                    oModel.setProperty("/recentAnalyses", aRecent);

                    // Navigate to result
                    that.getOwnerComponent()
                        .getRouter()
                        .navTo("result");
                })
                .catch(function (err) {
                    MessageBox.error("Analysis failed: " + err.message);
                })
                .finally(function () {
                    that.byId("busyIndicator").setVisible(false);
                    that.byId("analyzeBtn").setEnabled(true);
                    that.byId("statusText").setText("");
                });
        },

        // ── Helpers ────────────────────────────────────────────────────────
        _formatAnalysisLabel: function (sKey) {
            var mLabels = {
                summarize:    "Document Summary",
                keypoints:    "Key Points",
                sentiment:    "Sentiment Analysis",
                action_items: "Action Items",
                risks:        "Risk Analysis"
            };
            return mLabels[sKey] || sKey;
        },

        onAboutPress: function () {
            MessageBox.information(
                "AI Document Analyzer v1.0\n\n" +
                "Built with SAP UI5 + Python Flask + LLaMA API\n" +
                "Developer: Adithyaram Gude\n" +
                "GitHub: github.com/adithyaramgude"
            );
        },

        onRecentTilePress: function () {
            MessageToast.show("Re-run from history coming soon!");
        }
    });
});
