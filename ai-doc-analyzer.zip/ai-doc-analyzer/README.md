# AI Document Analyzer
### SAP UI5 + Python Flask + LLaMA API (Groq)
**Developer:** Adithyaram Gude

---

## What It Does
Upload any business document (.txt or .pdf) and get instant AI-powered analysis:
- 📄 Document Summarization
- 🔑 Key Points Extraction
- 💬 Sentiment Analysis
- ✅ Action Items Extraction
- ⚠️ Risk Identification

---

## Tech Stack

| Layer     | Technology                        |
|-----------|-----------------------------------|
| Frontend  | SAP UI5 (XMLViews, MVC, Routing)  |
| Backend   | Python Flask + REST API           |
| AI Model  | LLaMA 3 via Groq API              |
| PDF Parse | PyPDF2                            |
| Styling   | SAP Horizon Theme (sap_horizon)   |

---

## Project Structure

```
ai-doc-analyzer/
├── webapp/                    # SAP UI5 Frontend
│   ├── index.html             # Bootstrap entry point
│   ├── Component.js           # UI5 Component definition
│   ├── manifest.json          # App config + routing
│   ├── view/
│   │   ├── App.view.xml       # Root nav container
│   │   ├── Home.view.xml      # Upload page
│   │   └── Result.view.xml    # Results page
│   └── controller/
│       ├── App.controller.js
│       ├── Home.controller.js  # File upload + API call
│       └── Result.controller.js# Display + export
└── backend/
    ├── app.py                  # Flask server + LLaMA integration
    └── requirements.txt
```

---

## Setup & Run

### Step 1 — Get Free Groq API Key
1. Go to https://console.groq.com
2. Sign up (free) → Create API Key
3. Copy your key

### Step 2 — Backend Setup
```bash
cd backend
pip install -r requirements.txt
export GROQ_API_KEY="your_groq_api_key_here"
python app.py
```
Backend runs on: http://localhost:5000

### Step 3 — Frontend Setup
```bash
cd webapp
# Option A: VS Code Live Server (easiest)
# Right-click index.html → Open with Live Server

# Option B: Python simple server
python -m http.server 8080
# Open: http://localhost:8080
```

### Step 4 — Test it!
1. Open http://localhost:8080 in browser
2. Upload a .txt file (paste any text into a .txt file)
3. Choose analysis type
4. Click "Analyze Document with AI"
5. View results on the Result page

---

## API Endpoints

| Method | Endpoint   | Description              |
|--------|------------|--------------------------|
| GET    | /health    | Check backend status     |
| POST   | /analyze   | Analyze document text    |

### POST /analyze — JSON Body
```json
{
  "text": "Your document text here...",
  "analysis_type": "summarize",
  "file_name": "report.txt"
}
```

### Analysis Types
| Key          | Description             |
|--------------|-------------------------|
| summarize    | Document summary        |
| keypoints    | Key points extraction   |
| sentiment    | Sentiment analysis      |
| action_items | Action items extraction |
| risks        | Risk identification     |

---

## Resume Bullet Points (Use These!)

- Built an enterprise AI Document Analyzer using **SAP UI5** with MVC architecture, XMLViews, multi-page routing, and JSON Model for dynamic data binding.
- Developed a **Python Flask REST API** backend integrating **LLaMA 3 via Groq API** for five analysis modes including summarization, sentiment analysis, and risk identification.
- Implemented **PDF and text file upload** in SAP UI5 using FileUploader control with client-side validation and FileReader API.
- Designed dynamic **GenericTile KPI dashboard** and **sap.m.Table** for structured insight display following SAP Fiori design guidelines.
- Engineered robust **JSON response parsing**, error handling, and export functionality (JSON download + clipboard copy).
